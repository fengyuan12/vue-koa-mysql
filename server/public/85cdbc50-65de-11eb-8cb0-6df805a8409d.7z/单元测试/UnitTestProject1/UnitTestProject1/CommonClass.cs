﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;

namespace UnitTestProject1
{
    public class CommonClass
    {
        public static string commonUrl = "http://localhost:55149/api/";

        public static string HttpGet(string url)
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            request.Proxy = null;
            request.KeepAlive = false;
            request.Method = "GET";
            request.ContentType = "application/json; charset=UTF-8";
            request.AutomaticDecompression = DecompressionMethods.GZip;

            try
            {
                using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                {
                    using (Stream responseStream = response.GetResponseStream())
                    {
                        using (StreamReader reader = new StreamReader(responseStream, Encoding.UTF8))
                        {
                            string result = reader.ReadToEnd();
                            return result;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                request.Abort();
            }
        }

        /// <summary>
        /// 把内容保存到文件
        /// </summary>
        /// <param name="content"></param>
        public static void SaveLog(string content)
        {
            string LogPath = "日志\\";
            if (!Directory.Exists(LogPath))
            {
                Directory.CreateDirectory(LogPath);
            }

            using (StreamWriter sw = new StreamWriter(LogPath + DateTime.Now.ToString("yyyy-MM-dd") + ".txt", true, Encoding.UTF8))
            {
                sw.WriteLine(content);
            }
        }

        public static void CommonTest(string url)
        {
            string fullUrl = CommonClass.commonUrl + url;

            string json = CommonClass.HttpGet(fullUrl);
            var result = JsonConvert.DeserializeObject<CommonResult>(json);

            //CommonClass.SaveLog(result.data.ToString());

            if (!result.success)
            {
                CommonClass.SaveLog("失败：" + url);
            }
            if (!string.IsNullOrEmpty(result.message))
            {
                CommonClass.SaveLog(url + "：" + result.message);
            }
        }
    }

    public class CommonResult
    {
        public bool success { get; set; }
        public string message { get; set; }
        public int count { get; set; }
        public object data { get; set; }
    }
}
