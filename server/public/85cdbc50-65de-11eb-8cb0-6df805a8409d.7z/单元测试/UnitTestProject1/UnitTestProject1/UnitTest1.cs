using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.IO;
using System.Net;

namespace UnitTestProject1
{
    //[TestClass]
    public class UnitTest1
    {
        /// <summary>
        /// ��ʿ������ͳ��
        /// </summary>
        //[TestMethod]
        public void TestMethod1()
        {
            return;

            string url = "http://localhost:55149/api/";
            url += "Costslist/exportExcel";
            url += "?PatientId=23faddb7-f3f9-bb8e-f666-4777a3009c17&CostslistName=&LogDate=";

           string result= HttpGet(url);
        }

        public string HttpGet(string url)
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            request.Proxy = null;
            request.KeepAlive = false;
            request.Method = "GET";
            request.ContentType = "application/json; charset=UTF-8";
            request.AutomaticDecompression = DecompressionMethods.GZip;

            try
            {
                using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                {
                    using (System.IO.Stream responseStream = response.GetResponseStream())
                    {
                        using (StreamReader reader = new StreamReader(responseStream, System.Text.Encoding.UTF8))
                        {
                            string result = reader.ReadToEnd();
                            return result;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                request.Abort();
            }
        }
    }
}
