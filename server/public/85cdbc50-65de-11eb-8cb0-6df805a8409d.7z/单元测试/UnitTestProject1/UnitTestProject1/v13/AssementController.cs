﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Text;

namespace UnitTestProject1.v13
{
    [TestClass]
    public class AssementController
    {
        string contr = "Assement/";

        [TestMethod]
        public void GetEnabledAnticoagulant()
        {
            string url = contr + "GetSzdialysisassementByPatientId";
            //url += "?PatientId=23faddb7-f3f9-bb8e-f666-4777a3009c17&CostslistName=&LogDate=";

            CommonClass.CommonTest(url);
        }
    }
}
